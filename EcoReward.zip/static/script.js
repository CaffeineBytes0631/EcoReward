document.addEventListener("DOMContentLoaded", function () {
    const forms = document.querySelectorAll(".action-form");

    forms.forEach(function (form) {
        form.addEventListener("submit", function (event) {
            const message = form.dataset.confirm;

            if (message && !window.confirm(message)) {
                event.preventDefault();
            }
        });
    });
});