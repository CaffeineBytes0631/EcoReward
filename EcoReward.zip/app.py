import os
import sqlite3
from functools import wraps
from pathlib import Path
from uuid import uuid4

from flask import (
    Flask, render_template, request, redirect,
    url_for, session, flash, abort
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

from db import get_db, init_db


BASE_DIR = Path(__file__).resolve().parent
UPLOAD_FOLDER = BASE_DIR / "uploads"

UPLOAD_FOLDER.mkdir(exist_ok=True)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get(
    "SECRET_KEY", "change-this-secret-before-deployment"
)
app.config["UPLOAD_FOLDER"] = str(UPLOAD_FOLDER)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "pdf"}

ACTIVITY_POINTS = {
    "Recycling": 20,
    "Tree Plantation": 30,
    "Cycling": 15,
    "Public Transport": 15,
    "Water Conservation": 20,
    "Waste Segregation": 20,
    "Energy Saving": 15,
}

ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "admin@ecoreward.local")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "EcoAdmin123!")


def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )


def login_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in first.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped_view


def admin_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if not session.get("is_admin"):
            flash("Admin access is required.", "warning")
            return redirect(url_for("admin_login"))
        return view(*args, **kwargs)
    return wrapped_view


@app.route("/")
def home():
    if session.get("is_admin"):
        return redirect(url_for("admin"))
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not name or not email or not password:
            flash("Please fill in all fields.", "danger")
            return render_template("register.html")

        if len(password) < 8:
            flash("Password must be at least 8 characters.", "danger")
            return render_template("register.html")

        conn = get_db()

        try:
            conn.execute(
                """INSERT INTO users (name, email, password_hash)
                   VALUES (?, ?, ?)""",
                (name, email, generate_password_hash(password))
            )
            conn.commit()

            # Automatically log in after registration
            user = conn.execute(
                "SELECT id, name FROM users WHERE email = ?",
                (email,)
            ).fetchone()

            session.clear()
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]

            flash("Registration successful! Welcome to EcoReward.", "success")
            return redirect(url_for("dashboard"))

        except sqlite3.IntegrityError:
            flash("This email is already registered. Please log in.", "danger")
            return redirect(url_for("login"))

        finally:
            conn.close()

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        conn = get_db()
        user = conn.execute(
            "SELECT * FROM users WHERE email = ?", (email,)
        ).fetchone()
        conn.close()

        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            return redirect(url_for("dashboard"))

        flash("Invalid email or password.", "danger")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    conn = get_db()

    user = conn.execute(
        "SELECT * FROM users WHERE id = ?",
        (session["user_id"],)
    ).fetchone()

    activities = conn.execute(
        """
        SELECT * FROM activities
        WHERE user_id = ?
        ORDER BY id DESC
        LIMIT 5
        """,
        (session["user_id"],)
    ).fetchall()

    stats = conn.execute(
        """
        SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) AS approved,
            SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) AS pending
        FROM activities
        WHERE user_id = ?
        """,
        (session["user_id"],)
    ).fetchone()

    conn.close()

    return render_template(
        "dashboard.html",
        user=user,
        activities=activities,
        stats=stats
    )


@app.route("/activities", methods=["GET", "POST"])
@login_required
def activities():
    if request.method == "POST":
        category = request.form.get("category", "")
        description = request.form.get("description", "").strip()
        proof = request.files.get("proof")

        if category not in ACTIVITY_POINTS:
            flash("Please select a valid activity.", "danger")
            return redirect(url_for("activities"))

        if len(description) < 5:
            flash("Please provide a little more detail.", "danger")
            return redirect(url_for("activities"))

        saved_filename = None

        if proof and proof.filename:
            if not allowed_file(proof.filename):
                flash("Proof must be PNG, JPG, JPEG, or PDF.", "danger")
                return redirect(url_for("activities"))

            original_name = secure_filename(proof.filename)
            extension = original_name.rsplit(".", 1)[1].lower()
            saved_filename = f"{uuid4().hex}.{extension}"
            proof.save(UPLOAD_FOLDER / saved_filename)

        conn = get_db()
        conn.execute(
            """
            INSERT INTO activities
                (user_id, category, description, proof_file, points, status)
            VALUES (?, ?, ?, ?, ?, 'Pending')
            """,
            (
                session["user_id"],
                category,
                description,
                saved_filename,
                ACTIVITY_POINTS[category],
            ),
        )
        conn.commit()
        conn.close()

        flash("Activity submitted for admin review!", "success")
        return redirect(url_for("activities"))

    conn = get_db()
    records = conn.execute(
        """
        SELECT * FROM activities
        WHERE user_id = ?
        ORDER BY id DESC
        """,
        (session["user_id"],)
    ).fetchall()
    conn.close()

    return render_template(
        "activities.html",
        activities=records,
        activity_points=ACTIVITY_POINTS
    )


@app.route("/leaderboard")
@login_required
def leaderboard():
    conn = get_db()
    users = conn.execute(
        """
        SELECT name, points
        FROM users
        ORDER BY points DESC, name ASC
        LIMIT 20
        """
    ).fetchall()
    conn.close()

    return render_template("leaderboard.html", users=users)


@app.route("/rewards")
@login_required
def rewards():
    conn = get_db()
    user = conn.execute(
        "SELECT points FROM users WHERE id = ?",
        (session["user_id"],)
    ).fetchone()
    conn.close()

    user_points = user["points"] if user and user["points"] else 0

    reward_items = [
        {
            "name": "Eco Starter",
            "description": "A digital eco-achievement badge.",
            "cost": 10,
            "icon": "🌱",
        },
        {
            "name": "Green Champion",
            "description": "A digital sustainability certificate.",
            "cost": 150,
            "icon": "🏆",
        },
        {
            "name": "Planet Protector",
            "description": "A special eco-achiever badge.",
            "cost": 300,
            "icon": "🌍",
        },
    ]
    return render_template("rewards.html", rewards=reward_items, points=user_points)

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if (
            email == ADMIN_EMAIL.lower()
            and password == ADMIN_PASSWORD
        ):
            session.clear()
            session["is_admin"] = True
            return redirect(url_for("admin"))

        flash("Invalid admin credentials.", "danger")

    return render_template("login.html", admin_mode=True)


@app.route("/admin")
@admin_required
def admin():
    conn = get_db()
    records = conn.execute(
        """
        SELECT activities.*, users.name, users.email
        FROM activities
        JOIN users ON users.id = activities.user_id
        ORDER BY
            CASE WHEN activities.status = 'Pending' THEN 0 ELSE 1 END,
            activities.id DESC
        """
    ).fetchall()
    conn.close()

    return render_template("admin.html", activities=records)



@app.route("/admin/review/<int:activity_id>", methods=["POST"])
@admin_required
def review_activity(activity_id):
    action = request.form.get("action")

    if action not in {"approve", "reject"}:
        abort(400)

    conn = get_db()
    activity = conn.execute(
        "SELECT * FROM activities WHERE id = ?",
        (activity_id,)
    ).fetchone()

    if not activity:
        conn.close()
        abort(404)

    if activity["status"] != "Pending":
        conn.close()
        flash("This activity has already been reviewed.", "warning")
        return redirect(url_for("admin"))

    if action == "approve":
        conn.execute(
            """
            UPDATE activities
            SET status = 'Approved'
            WHERE id = ? AND status = 'Pending'
            """,
            (activity_id,)
        )
        conn.execute(
            "UPDATE users SET points = points + ? WHERE id = ?",
            (activity["points"], activity["user_id"])
        )
        flash("Activity approved and points awarded.", "success")
    else:
        conn.execute(
            """
            UPDATE activities
            SET status = 'Rejected'
            WHERE id = ? AND status = 'Pending'
            """,
            (activity_id,)
        )
        flash("Activity rejected.", "success")

    conn.commit()
    conn.close()
    return redirect(url_for("admin"))


@app.route("/admin/proof/<int:activity_id>")
@admin_required
def view_proof(activity_id):
    from flask import send_from_directory

    conn = get_db()
    activity = conn.execute(
        "SELECT proof_file FROM activities WHERE id = ?",
        (activity_id,)
    ).fetchone()
    conn.close()

    if not activity or not activity["proof_file"]:
        abort(404)

    return send_from_directory(
        app.config["UPLOAD_FOLDER"],
        activity["proof_file"],
        as_attachment=False
    )


@app.errorhandler(413)
def file_too_large(error):
    flash("File is too large. Maximum size is 5 MB.", "danger")
    return redirect(url_for("activities"))


with app.app_context():
    init_db()

@app.route("/redeem", methods=["POST"])
@login_required
def redeem():
    cost = int(request.form.get("cost", 0))
    reward_name = request.form.get("name", "Reward")

    conn = get_db()
    user = conn.execute(
        "SELECT points FROM users WHERE id = ?",
        (session["user_id"],)
    ).fetchone()

    if user and user["points"] >= cost:
        # Deduct points
        conn.execute(
            "UPDATE users SET points = points - ? WHERE id = ?",
            (cost, session["user_id"])
        )
        conn.commit()
        flash(f"Successfully redeemed {reward_name}! 🎉", "success")
    else:
        flash("Not enough EcoPoints to redeem this reward.", "danger")

    conn.close()
    return redirect(url_for("rewards"))

if __name__ == "__main__":
    app.run(debug=True)